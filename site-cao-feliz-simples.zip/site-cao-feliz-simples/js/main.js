/* ==============================================================
   Cão Feliz — main.js
   Camada de "banco de dados" simulado (localStorage) para o MVP.
   Ver documentação técnica para o caminho de evolução para um
   banco real (Firebase / Supabase / Planilha Google via Apps Script).
   ============================================================== */

const CF = (() => {
  const STORAGE_KEY = "cf_agendamentos_v1";
  const SHOP_ADDRESS = "Rua das Acácias, 120 - Centro, Florianópolis - SC";

  function getAll() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("Erro ao ler agendamentos:", e);
      return [];
    }
  }

  function saveAll(list) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  }

  function generateCode() {
    return "CF-" + Math.random().toString(36).slice(2, 7).toUpperCase();
  }

  function addAgendamento(data) {
    const list = getAll();
    const record = {
      id: generateCode(),
      status: "pendente",
      criadoEm: new Date().toISOString(),
      ...data,
    };
    list.push(record);
    saveAll(list);
    return record;
  }

  function updateStatus(id, status) {
    const list = getAll();
    const idx = list.findIndex((r) => r.id === id);
    if (idx > -1) {
      list[idx].status = status;
      saveAll(list);
    }
    return list;
  }

  function removeAgendamento(id) {
    const list = getAll().filter((r) => r.id !== id);
    saveAll(list);
    return list;
  }

  function mapsRouteUrl(enderecoCompleto) {
    const origin = encodeURIComponent(SHOP_ADDRESS);
    const dest = encodeURIComponent(enderecoCompleto);
    return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${dest}&travelmode=driving`;
  }

  function toCSV(list) {
    const headers = [
      "codigo",
      "status",
      "tutor",
      "telefone",
      "pet",
      "raca",
      "endereco",
      "bairro",
      "cidade",
      "cep",
      "data",
      "horario",
      "servico",
      "observacoes",
      "criadoEm",
    ];
    const rows = list.map((r) =>
      headers
        .map((h) => `"${String(r[h] ?? "").replace(/"/g, '""')}"`)
        .join(",")
    );
    return [headers.join(","), ...rows].join("\n");
  }

  function downloadCSV(list, filename = "agendamentos-cao-feliz.csv") {
    const csv = toCSV(list);
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return {
    getAll,
    addAgendamento,
    updateStatus,
    removeAgendamento,
    mapsRouteUrl,
    downloadCSV,
    SHOP_ADDRESS,
  };
})();

/* ---------- Nav mobile toggle (compartilhado) ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector("[data-nav-toggle]");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => {
      links.classList.toggle("open");
    });
  }
});
